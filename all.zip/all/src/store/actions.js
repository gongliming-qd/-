export default{
      // 1. 全局语言
        make({commit},num){
            commit('changeLanguage',num)
        }
}