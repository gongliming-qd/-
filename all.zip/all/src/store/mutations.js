export default{
     // 1. 修改全局语言
        changeLanguage(state,date){
            state.language = date
        }
}