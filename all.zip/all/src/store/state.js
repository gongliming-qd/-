export default{
     // 1. 全局语言
     language: 0
}